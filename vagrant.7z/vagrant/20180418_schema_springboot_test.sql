﻿-------------------------------------------------------------
 /**
 * Author:  p.ruggiero, l.duperron
 * Created: 18 mai 2018
 */
-------------------------------------------------------------

DO $$ DECLARE
    r RECORD;
BEGIN
    FOR r IN (SELECT tablename FROM pg_tables WHERE schemaname = current_schema()) LOOP
        EXECUTE 'DROP TABLE IF EXISTS ' || (r.tablename) || ' CASCADE';
    END LOOP;
END $$;

CREATE TABLE IF NOT EXISTS springboot_test_db.public.utilisateur(
  user_id serial NOT NULL PRIMARY KEY,
  user_login varchar(30) NOT null unique,
  user_etat_activite integer
);

CREATE TABLE IF NOT EXISTS springboot_test_db.public.droit(
  droit_id serial NOT NULL PRIMARY KEY,
  droit_nom varchar(30) NOT null unique 
);

CREATE TABLE IF NOT EXISTS springboot_test_db.public.droits_par_utilisateur(
  user_id integer NOT null,
  droit_id integer NOT null,
  primary key (user_id, droit_id),
  constraint fk_utilisateur 
	foreign key (user_id) 
	references utilisateur (user_id)
	on delete restrict
	on update restrict,
  constraint fk_droit 
	foreign key (droit_id) 
	references droit (droit_id)
	on delete restrict
	on update restrict
);