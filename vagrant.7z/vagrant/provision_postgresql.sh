#!/bin/sh -e
echo "PROVISION BDD PostgreSQL"
# Edit the following to change the name of the database user that will be created:
APP_DB_USER=springboot
APP_DB_PASS=$APP_DB_USER"pass"

# Edit the following to change the name of the database that is created (defaults to the user name)
APP_DB_NAME=$APP_DB_USER"_db"
APP_DB_TEST_NAME=$APP_DB_USER"_test_db"

# Edit the following to change the version of PostgreSQL that is installed
PG_VERSION=9.2
POSTGRES_USER="postgres"
MDP_POSTGRES_USER="postgres"

#---------------------------------------------------------------------------------------------
print_db_usage () {
  echo "  Les bases de données Postgresql sont accessible  (default: 5432)"
  echo "  Host: 192.168.56.102"
  echo "  Port: 5432"
  echo "  Database: $APP_DB_NAME"
  echo "  Database: $APP_DB_TEST_NAME"
  echo "  Username: $APP_DB_USER"
  echo "  Password: $APP_DB_PASS"
  echo ""
  echo "  Admin access to postgres user via VM:"
  echo "  vagrant ssh postgresql"
  echo "  sudo su - postgres"
  echo ""
  echo "  psql access to app database user via VM:"
  echo "  vagrant ssh"
  echo "  sudo su - postgres"
  echo "  PGUSER=$APP_DB_USER PGPASSWORD=$APP_DB_PASS psql -h 192.168.56.102 $APP_DB_NAME"
  echo "  PGUSER=$APP_DB_USER PGPASSWORD=$APP_DB_PASS psql -h 192.168.56.102 $APP_DB_TEST_NAME"
  echo ""
  echo "  Env variable for application development:"
  echo "  DATABASE_URL=postgresql://$APP_DB_USER:$APP_DB_PASS@192.168.56.102:15432/$APP_DB_NAME"
  echo "  DATABASE_URL=postgresql://$APP_DB_USER:$APP_DB_PASS@192.168.56.102:15432/$APP_DB_TEST_NAME"
  echo ""
  echo "  Local command to access the database via psql:"
  echo "  PGUSER=$APP_DB_USER PGPASSWORD=$APP_DB_PASS psql -h 192.168.56.102 -p 15432 $APP_DB_NAME"
  echo "  PGUSER=$APP_DB_USER PGPASSWORD=$APP_DB_PASS psql -h 192.168.56.102 -p 15432 $APP_DB_TEST_NAME"
}
#---------------------------------------------------------------------------------------------
# fonction d'approvisionnement du schema springboot
deploy_schema_springboot (){

sudo cp /vagrant/20180418_schema_springboot.sql /var/lib/pgsql/20180418_schema_springboot.sql
sudo cp /vagrant/20180418_schema_springboot_test.sql /var/lib/pgsql/20180418_schema_springboot_test.sql
cat << EOF | su - $POSTGRES_USER PGPASSWORD=$MDP_POSTGRES_USER -c psql 
\c $APP_DB_NAME $APP_DB_USER
\i 20180418_schema_springboot.sql
\c $APP_DB_TEST_NAME $APP_DB_USER
\i 20180418_schema_springboot_test.sql
EOF
echo "Le schema springboot a été installé avec succés"
}
#---------------------------------------------------------------------------------------------
PROVISIONED_ON=/etc/vm_provision_on_timestamp

if [ -f "$PROVISIONED_ON" ]
then
  echo "La machine viruelle a déjà été provisonnée : $(cat $PROVISIONED_ON)"
  echo "Pour mettre à jour le systeme, utiliser 'vagrant ssh' et lancer 'yum update && yum upgrade'"
  echo ""
  print_db_usage
  
  deploy_schema_springboot
  exit
fi

#---------------------------------------------------------------------------------------------
# Update package list and upgrade all packages
sudo yum -y update
sudo yum -y upgrade

#---------------------------------------------------------------------------------------------

echo "------ Installation du serveur de BDD ... "

sudo yum -y install postgresql-server postgresql-contrib postgresql-devel

#---------------------------------------------------------------------------------------------
# Changement de  password for the user posgres
echo "------ Ajout de l'utilisateur postgres et changement du password ... "

if [ -z $(getent passwd $POSTGRES_USER)  ]; then
sudo useradd $POSTGRES_USER
fi
sudo passwd $POSTGRES_USER <<EOF
$MDP_POSTGRES_USER
$MDP_POSTGRES_USER
EOF
echo "------ fin ajout de l'utilisateur postgres et changement du password ... "



echo "------ Initialisation de la base de données ..."
sudo mkdir /home/postgres
sudo mkdir /home/postgres/data

su - $POSTGRES_USER<<EOF
$MDP_POSTGRES_USER
initdb -D /var/lib/pgsql/data
echo  '1ere connexion avec le compte postgres et rep data existe'
EOF

#sudo sed "s|PGDATA=/var/lib/pgsql/data|PGDATA=/home/postgres/data|" "/var/lib/pgsql/.bash_profile"
#su - $POSTGRES_USER<<EOF
#$MDP_POSTGRES_USER
#source /var/lib/pgsql/.bash_profile
#EOF
#---------------------------------------------------------------------------------------------
echo "----- Modification du fichier de configuration postgresql.conf ..."
# Constantes definissants la localisation des fichiers de conf.
PG_CONF="/var/lib/pgsql/data/postgresql.conf"


# Edit postgresql.conf to change listen address to '*':
sudo sed -i.back "s/#listen_addresses = 'localhost'/listen_addresses = '*'/" "$PG_CONF"
sudo sed -i "s/#port = 5432/port = 5432/" "$PG_CONF"
sudo sed -i "s/max_connections = 100/max_connections = 50/" "$PG_CONF"
sudo sed -i "s/shared_buffers = 128MB/shared_buffers = 300MB/" "$PG_CONF"
#sudo sed -i "s/#work_mem = 4MB/work_mem = 10MB/" "$PG_CONF"
sudo sed -i "s/en_US.UTF-8/fr_FR.UTF-8/g" "$PG_CONF"
echo "----- Fin modification du fichier de configuration postgresql.conf."
#---------------------------------------------------------------------------------------------
echo "----- Modification du fichier d'authentification pg_hba.conf ..."
sudo cp /var/lib/pgsql/data/pg_hba.conf /var/lib/pgsql/data/pg_hba.conf.back
sudo cat >>pg_hba.conf<<EOF
# PostgreSQL Client Authentication Configuration File
# ===================================================

# TYPE  DATABASE              USER            ADDRESS                 METHOD

# "local" is for Unix domain socket connections only
local   all                  all                                     trust
# IPv4 local connections:
host    $APP_DB_NAME        $APP_DB_USER       all                    trust
host    $APP_DB_TEST_NAME   $APP_DB_USER       all                    trust
#host   all                  all              all                    trust
# IPv6 local connections:
host    all                  all             ::1/128                 trust
# Allow replication connections from localhost, by a user with the
# replication privilege.
local   replication          all                                     trust
host    replication          all             127.0.0.1/32            trust
host    replication          all             ::1/128                 trust
host    springboot_db		 postgres		 192.168.56.1/24		 trust
host    springboot_test_db	 postgres		 192.168.56.1/24		 trust

EOF

sudo mv pg_hba.conf /var/lib/pgsql/data/pg_hba.conf
sudo chown $POSTGRES_USER:$POSTGRES_USER /var/lib/pgsql/data/pg_hba.conf

echo "----- Fin modification du fichier d'authentification pg_hba.conf"
#---------------------------------------------------------------------------------------------
# Disable firewalld pour retirer le mesure de bloquage de certain port
echo "----- Désactivation du Firewalld  ..."
sudo systemctl disable firewalld.service
echo "----- Fin désactivation Firewalld."
#---------------------------------------------------------------------------------------------
echo "----- Demarrage de postgresql ..."
su - $POSTGRES_USER -c 'pg_ctl start -l /var/lib/pgsql/serverlog'<<EOF
$MDP_POSTGRES_USER
EOF
echo "enable service postgresql"

sudo systemctl enable postgresql.service 

#---------------------------------------------------------------------------------------------
echo "----- Création des bases de données ..."
cat << EOF | su - postgres PGPASSWORD=$MDP_POSTGRES_USER -c psql  
-- Create the database user:
CREATE USER $APP_DB_USER WITH ENCRYPTED PASSWORD '$APP_DB_PASS';
ALTER ROLE $APP_DB_USER WITH CREATEDB;
GRANT ALL ON ALL TABLES IN SCHEMA public TO springboot;
-- Create the database:
CREATE DATABASE $APP_DB_NAME WITH OWNER=$APP_DB_USER
                                  LC_COLLATE='fr_FR.utf8'
                                  LC_CTYPE='fr_FR.utf8'
                                  ENCODING='UTF8'
                                  TEMPLATE=template0;
-- Create the test database:
CREATE DATABASE $APP_DB_TEST_NAME WITH OWNER=$APP_DB_USER
                                  LC_COLLATE='fr_FR.utf8'
                                  LC_CTYPE='fr_FR.utf8'
                                  ENCODING='UTF8'
                                  TEMPLATE=template0;

EOF

deploy_schema_springboot
echo "----- Fin création des bases de données."
#---------------------------------------------------------------------------------------------
# Tag the provision time:
date > "$PROVISIONED_ON"
#---------------------------------------------------------------------------------------------
echo "Machine virtuelle PostgreSQL créée avec SUCCES."
echo ""
print_db_usage

