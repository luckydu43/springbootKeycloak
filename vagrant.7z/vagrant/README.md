# installation des machines virtuelles 
## Applicab-Postgresql 

Le projet est découpé en 3 répertoires


* 1-analyse qui contient les sources de la modélisation avec le studio safran
* 2-virtualisation_vagrant qui contient les sources pour virtualiser l'environnement de développement
* 3-workspace qui contient les sources java de l'application

les opérations seront menées dans le répertoire 2-virtualisation_vagrant

**Pré-requis:** 

bills-kitchen-3.0 doit être installé et configuré

 * monter le répertoire W:\
 * lancer virtualbox
 * lancer conEmu

dans le répertoire vous devez avoir les fichiers suivants:

 * vagrantfile
 * provision_postgresql.sh
 * 20180418_schema_recompense.sql
 * centos-7.4-IAP7.box (la box est disponible sur le NAS du CCIAT /outils/Isos/Boxes_vagrant)
 
**Procédures**

Sur comEmu se positionner dans le répertoire **2-virtualisation_vagrant**
 et vérifier la présence de la box centos7.4

  ``$vagrant box list``

Dans la négative, ajouter la box dans le catalogue vagrant

  ``$vagrant box add centos7.4 centos-7.4-IAP7.box``

Lorsque la box est ajouté vous pouvez installer l'environnment de développement

   ``$vagrant up``

en cas de modification de la base de données, remplacer le fichier 20180418_schema_recompense.sql et provisionner de nouveau la machine virtuelle.

  ``$vagrant provision``
